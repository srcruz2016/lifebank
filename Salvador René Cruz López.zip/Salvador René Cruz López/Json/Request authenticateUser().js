URL: localhost:90/integrator/v1/authentication/login

Request:

Header requerido: ipAddress : 127.0.0.1 -> Direccion IP
{
	"userName" :"tstark",
	"password": "provisional"
}