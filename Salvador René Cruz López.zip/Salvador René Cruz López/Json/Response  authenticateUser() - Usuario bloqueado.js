{
  "code": "400",
  "message": "User Blocked"
}