-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::LIFEBANK_SCHEMA:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::SCHEMA DEFINITION:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
--DROP SCHEMA if exists lb_op_autenticacion CASCADE;
create schema if not exists lb_op_autenticacion;


/*=======================================================================================
======== Script de creacion de base de datos lifebank-authentication-svc =================
========================================================================================*/

set search_path to lb_op_autenticacion;

drop index if exists idx_clientes_doc_identidad;
drop index if exists idx_clientes_nombre_usuario;
drop index if exists idx_clientes_correo_electronico;
drop index if exists idx_estados_descripcion;

alter table if exists productos drop constraint if exists prd_id_cliente_fk;
alter table if exists productos drop constraint if exists prd_tipo_producto_fk;
alter table if exists productos drop constraint if exists prd_id_estado_fk;
alter table if exists transaciones drop constraint if exists tra_id_cliente_fk;
alter table if exists transaciones drop constraint if exists tra_id_producto_fk;
alter table if exists transaciones drop constraint if exists tra_id_estado_fk;
alter table if exists beneficiarios drop constraint if exists ben_id_cliente_fk;
alter table if exists beneficiarios drop constraint if exists ben_id_estado_fk;
alter table if exists autenticaciones drop constraint if exists aut_id_estado_fk;


drop table if exists lb_op_autenticacion.clientes cascade;
drop table if exists lb_op_autenticacion.estados cascade;
drop table if exists lb_op_autenticacion.autenticaciones cascade;

create table lb_op_autenticacion.clientes(
	cli_id_cliente varchar(8) not null,
    cli_doc_identidad varchar(15) not null,
    cli_nombre_usuario varchar(10) not null unique,    
    cli_nombre1 varchar(20) not null,
    cli_nombre2 varchar(20),
    cli_apellido1 varchar(20) not null,
    cli_apellido2 varchar(20),
    cli_password varchar(200) not null,
	cli_estado smallint not null,
	cli_correo_electronico varchar(80) not null unique,  
    cli_fecha_creacion timestamp default localtimestamp not null,
    cli_creado_por varchar(50) not null,
    cli_fecha_actualizacion timestamp default localtimestamp not null,
    cli_actualizado_por varchar(50) not null,
    constraint clientes_pk primary key(cli_id_cliente)
);

create table lb_op_autenticacion.estados(
    std_id_estado smallint not null,
    std_estado varchar(15) not null,
    std_fecha_creacion timestamp default localtimestamp not null,
    std_creado_por varchar(50) not null,
    std_fecha_actualizacion timestamp default localtimestamp not null,
    std_actualizado_por varchar(50) not null,    
    constraint estados_pk primary key(std_id_estado)
);

create table lb_op_autenticacion.autenticaciones(
	aut_id_autenticacion integer not null,
	aut_id_cliente varchar(8) not null,    
	aut_estado smallint not null,
	aut_ip_address varchar(40) not null,
	aut_observaciones varchar(250) not null,	
    aut_fecha_inicio_sesion timestamp default localtimestamp not null,
    constraint autentes_pk primary key(aut_id_autenticacion)
);

alter table lb_op_autenticacion.clientes add constraint cli_estado_fk foreign key(cli_estado) references lb_op_autenticacion.estados(std_id_estado)
on update cascade on delete restrict;

alter table lb_op_autenticacion.autenticaciones add constraint aut_id_estado_fk foreign key(aut_estado) references lb_op_autenticacion.estados(std_id_estado)
on update cascade on delete restrict;

alter table lb_op_autenticacion.autenticaciones add constraint aut_id_cliente_fk foreign key(aut_id_cliente) references lb_op_autenticacion.clientes(cli_id_cliente)
on update cascade on delete restrict;


create index idx_clientes_doc_identidad on lb_op_autenticacion.clientes(cli_doc_identidad);
create index idx_clientes_nombre_usuario on lb_op_autenticacion.clientes(cli_nombre_usuario);
create index idx_clientes_correo_electronico on lb_op_autenticacion.clientes(cli_correo_electronico);
create index idx_estados_descripcion on lb_op_autenticacion.estados(std_estado);