
	insert into lb_op_autenticacion.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (1,'ENTREGADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_op_autenticacion.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (2,'PAGADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_op_autenticacion.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (3,'ACTIVO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_op_autenticacion.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (4,'DESHABILITADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_op_autenticacion.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (5,'BLOQUEADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_op_autenticacion.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (6,'EXITOSO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_op_autenticacion.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (7,'FALLIDO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_op_autenticacion.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (8,'REVERTIDO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_op_autenticacion.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (9,'PROCESADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');


	commit;



	insert into lb_op_autenticacion.clientes values ('28156794','28156794-AB','vkstark','Veronica','','Stark','','iKOEaJSQwsVfi2sLgsCS71bFfk8ZFTPxtE0mGFwoGjLFoSYhBjadcFdBbNJUhbC/pNQrqoc/OkBQhV+f8qU37Q==',3,'vero@Stark.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_op_autenticacion.clientes values ('21556785','21556785-AC','bbanner','Bruce','','Banner','','ENj63C08ZHLK3U4PuNgf9+mp6sILLbkI2TpDQGWV80j1Gw1RAoZ8oO4LsdLezr/+H/99liJ7rSq2IAJuFwnGeA==',3,'bruce@banner.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_op_autenticacion.clientes values ('21556786','21556786-AF','tstark','Tony','','Stark','','f1n9ZdThCJ0RFUUvg91yOksWrLPDKmUmy2Zp2sq1WIt6zgHCgfYI8D/d0sN++BvkBKsbV4jTBGz4PXjk42dUfw==',3,'tony@stark.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_op_autenticacion.clientes values ('21556787','21556787-AG','tsith','Thanos','','Sith','','R5NebvpUlM4Sfa3fBqOsPtHmu5Vw/hHK9SeasShephg/ckY2RMUuAn6Sflz9LyH6td04VtPJ9LhKDVctnrplhw==',3,'thanos@sith.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_op_autenticacion.clientes values ('21578708','21578708-AD','obwkenobi','Obi','Wan','kenobi','','ChxF3WXsHjJJSwQkVKyOw6yqXRnh1K3dCLRnbjJXEaLt/kUBeobQAhSwfqV1FAmX+wL4752GjuKSJmF7QKS22Q==',3,'obi.wan@kenobi.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	commit;



