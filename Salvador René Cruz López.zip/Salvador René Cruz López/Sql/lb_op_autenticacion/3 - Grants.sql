grant usage on schema lb_op_autenticacion to [usuario_a_conceder_permisos];
grant select on all tables in schema lb_op_autenticacion to [usuario_a_conceder_permisos];
grant select, insert, update, delete on all tables in schema lb_op_autenticacion to [usuario_a_conceder_permisos];
grant usage, select on all sequences in schema lb_op_autenticacion to [usuario_a_conceder_permisos];
grant all privileges on all sequences in schema lb_op_autenticacion to [usuario_a_conceder_permisos];