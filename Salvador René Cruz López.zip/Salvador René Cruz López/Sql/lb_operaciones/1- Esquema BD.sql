-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::LIFEBANK_SCHEMA:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::SCHEMA DEFINITION:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
--DROP SCHEMA if exists lb_operaciones CASCADE;
create schema if not exists lb_operaciones;


/*=======================================================================================
======== Scrip de creacion de base de datos de LIFEBANK Operaciones ======================
========================================================================================*/

set search_path to lb_operaciones;

drop index if exists idx_clientes_doc_identidad;
drop index if exists idx_clientes_nombre_usuario;
drop index if exists idx_clientes_correo_electronico;
drop index if exists idx_productos_numero_cuenta;
drop index if exists idx_estados_descripcion;
drop index if exists idx_transaciones_numero_transaccion;
drop index if exists idx_beneficiario_numero_cuenta;
drop index if exists idx_beneficiario_correo_electronico;


alter table if exists productos drop constraint if exists prd_id_cliente_fk;
alter table if exists productos drop constraint if exists prd_tipo_producto_fk;
alter table if exists productos drop constraint if exists prd_id_estado_fk;
alter table if exists transaciones drop constraint if exists tra_id_cliente_fk;
alter table if exists transaciones drop constraint if exists tra_id_producto_fk;
alter table if exists transaciones drop constraint if exists tra_id_estado_fk;
alter table if exists beneficiarios drop constraint if exists ben_id_cliente_fk;
alter table if exists beneficiarios drop constraint if exists ben_id_estado_fk;
alter table if exists autenticaciones drop constraint if exists aut_id_estado_fk;

drop table if exists lb_operaciones.clientes cascade;
drop table if exists lb_operaciones.productos cascade;
drop table if exists lb_operaciones.tipo_productos cascade;
drop table if exists lb_operaciones.estados cascade;
drop table if exists lb_operaciones.tipo_transacciones cascade;
drop table if exists lb_operaciones.transaciones cascade;
drop table if exists lb_operaciones.beneficiarios cascade;
drop table if exists lb_operaciones.autenticaciones cascade;



create table lb_operaciones.clientes(
	cli_id_cliente varchar(8) not null,
    cli_doc_identidad varchar(15) not null,
    cli_nombre_usuario varchar(10) not null unique,    
    cli_nombre1 varchar(20) not null,
    cli_nombre2 varchar(20),
    cli_apellido1 varchar(20) not null,
    cli_apellido2 varchar(20),
    cli_password varchar(200) not null,
	cli_estado smallint not null,
	cli_correo_electronico varchar(80) not null unique,  
    cli_fecha_creacion timestamp default localtimestamp not null,
    cli_creado_por varchar(50) not null,
    cli_fecha_actualizacion timestamp default localtimestamp not null,
    cli_actualizado_por varchar(50) not null,
    constraint clientes_pk primary key(cli_id_cliente)
);


create table lb_operaciones.productos(
    prd_id_producto varchar(8) not null,
	prd_numero_cuenta integer not null unique,
	prd_nombre_producto varchar(50) not null,
	prd_id_tipo_producto varchar(8) not null,		
    prd_id_cliente varchar(8) not null,   
    prd_id_estado smallint not null,	
	prd_monto_otorgado money not null,
	prd_saldo_actual money not null,
	prd_tasa_de_interes decimal(4,2) not null,
	prd_total_interes_acumulado money not null,
    prd_fecha_entrega timestamp,
    prd_fecha_creacion timestamp default localtimestamp not null,
    prd_creado_por varchar(50) not null,
    prd_fecha_actualizacion timestamp default localtimestamp not null,
    prd_actualizado_por varchar(50) not null,    
    constraint productos_pk primary key(prd_id_producto)    
);


create table lb_operaciones.tipo_productos(
    tpr_id_tipo_producto varchar(8) not null,
	tpr_nombre varchar(100) not null,
	tpr_descripcion varchar(200) not null, 
    tpr_fecha_creacion timestamp default localtimestamp not null,
    tpr_creado_por varchar(50) not null,
    tpr_fecha_actualizacion timestamp default localtimestamp not null,
    tpr_actualizado_por varchar(50) not null,    
    constraint t_productos_pk primary key(tpr_id_tipo_producto)    
);


create table lb_operaciones.estados(
    std_id_estado smallint not null,
    std_estado varchar(15) not null,
    std_fecha_creacion timestamp default localtimestamp not null,
    std_creado_por varchar(50) not null,
    std_fecha_actualizacion timestamp default localtimestamp not null,
    std_actualizado_por varchar(50) not null,    
    constraint estados_pk primary key(std_id_estado)
);


create table lb_operaciones.tipo_transacciones(
    ttr_id_tipo_transaccion varchar(8) not null,
	ttr_nombre varchar(200) not null,
	ttr_descripcion varchar(200) not null, 
    ttr_fecha_creacion timestamp default localtimestamp not null,
    ttr_creado_por varchar(50) not null,
    ttr_fecha_actualizacion timestamp default localtimestamp not null,
    ttr_actualizado_por varchar(50) not null,    
    constraint t_transaccion_pk primary key(ttr_id_tipo_transaccion)    
);


create table lb_operaciones.transaciones(
    tra_id_transaccion integer not null,
	tra_id_tipo_transaccion varchar(8) not null,
	tra_numero_autorizacion varchar(10) not null unique,	
	tra_id_producto varchar(8) not null,	
    tra_id_cliente varchar(8) not null,
	tra_id_estado smallint not null,
    tra_fecha_transaccion timestamp,
	tra_fecha_proceso timestamp,
	tra_monto money not null,
	tra_descripcion varchar(200) not null,
	tra_cuenta_destino integer not null,
    tra_fecha_creacion timestamp default localtimestamp not null,
    tra_creado_por varchar(50) not null,
    tra_fecha_actualizacion timestamp default localtimestamp not null,
    tra_actualizado_por varchar(50) not null,    
    constraint transaciones_pk primary key(tra_id_transaccion)    
);


create table lb_operaciones.beneficiarios(
    ben_numero_cuenta varchar(15) not null,    
    ben_pri_nombre varchar(20) not null,
    ben_pri_apellido varchar(20) not null,
	ben_correo_electronico varchar(80) not null,
	ben_id_cliente varchar(8) not null,
	ben_estado smallint not null,
    ben_fecha_creacion timestamp default localtimestamp not null,
    ben_creado_por varchar(50) not null,
    ben_fecha_actualizacion timestamp default localtimestamp not null,
    ben_actualizado_por varchar(50) not null,
    constraint benentes_pk primary key(ben_numero_cuenta)
);


create table lb_operaciones.autenticaciones(
	aut_id_autenticacion integer not null,
	aut_id_cliente varchar(8) not null,    
	aut_estado smallint not null,	
	aut_ip_address varchar(40) not null, 
	aut_observaciones varchar(250) not null,
    aut_fecha_inicio_sesion timestamp default localtimestamp not null,
    constraint autentes_pk primary key(aut_id_autenticacion)
);

alter table lb_operaciones.clientes add constraint cli_estado_fk foreign key(cli_estado) references lb_operaciones.estados(std_id_estado)
on update cascade on delete restrict;

alter table lb_operaciones.productos add constraint prd_id_cliente_fk foreign key(prd_id_cliente) references lb_operaciones.clientes(cli_id_cliente)
on update cascade on delete restrict;

alter table lb_operaciones.productos add constraint prd_tipo_producto_fk foreign key(prd_id_tipo_producto) references lb_operaciones.tipo_productos(tpr_id_tipo_producto)
on update cascade on delete restrict;

alter table lb_operaciones.productos add constraint prd_id_estado_fk foreign key(prd_id_estado) references lb_operaciones.estados(std_id_estado)
on update cascade on delete restrict;


alter table lb_operaciones.transaciones add constraint tra_id_cliente_fk foreign key(tra_id_cliente) references lb_operaciones.clientes(cli_id_cliente)
on update cascade on delete restrict;

alter table lb_operaciones.transaciones add constraint tra_id_producto_fk foreign key(tra_id_producto) references lb_operaciones.productos(prd_id_producto)
on update cascade on delete restrict;

alter table lb_operaciones.transaciones add constraint tra_id_estado_fk foreign key(tra_id_estado) references lb_operaciones.estados(std_id_estado)
on update cascade on delete restrict;

alter table lb_operaciones.transaciones add constraint tra_tipo_transaccion_fk foreign key(tra_id_tipo_transaccion) references lb_operaciones.tipo_transacciones(ttr_id_tipo_transaccion)
on update cascade on delete restrict;

alter table lb_operaciones.beneficiarios add constraint ben_id_cliente_fk foreign key(ben_id_cliente) references lb_operaciones.clientes(cli_id_cliente)
on update cascade on delete restrict;
alter table lb_operaciones.beneficiarios add constraint ben_id_estado_fk foreign key(ben_estado) references lb_operaciones.estados(std_id_estado)
on update cascade on delete restrict;

alter table lb_operaciones.autenticaciones add constraint aut_id_estado_fk foreign key(aut_estado) references lb_operaciones.estados(std_id_estado)
on update cascade on delete restrict;

alter table lb_operaciones.autenticaciones add constraint aut_id_cliente_fk foreign key(aut_id_cliente) references lb_operaciones.clientes(cli_id_cliente)
on update cascade on delete restrict;


create index idx_clientes_doc_identidad on lb_operaciones.clientes(cli_doc_identidad);
create index idx_clientes_nombre_usuario on lb_operaciones.clientes(cli_nombre_usuario);
create index idx_clientes_correo_electronico on lb_operaciones.clientes(cli_correo_electronico);
create index idx_productos_numero_cuenta on lb_operaciones.productos(prd_numero_cuenta);
create index idx_estados_descripcion on lb_operaciones.estados(std_estado);
create index idx_transaciones_numero_transaccion on lb_operaciones.transaciones(tra_numero_autorizacion);
create index idx_beneficiario_numero_cuenta on lb_operaciones.beneficiarios(ben_numero_cuenta);
create index idx_beneficiario_correo_electronico on lb_operaciones.beneficiarios(ben_correo_electronico);

