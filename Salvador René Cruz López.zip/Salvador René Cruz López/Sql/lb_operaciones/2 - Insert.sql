
	insert into lb_operaciones.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (1,'ENTREGADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (2,'PAGADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (3,'ACTIVO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (4,'DESHABILITADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (5,'BLOQUEADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (6,'EXITOSO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (7,'FALLIDO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (8,'REVERTIDO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.estados (std_id_estado, std_estado, std_fecha_creacion, std_creado_por, std_fecha_actualizacion, std_actualizado_por) 
	values (9,'PROCESADO', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');


	commit;



	insert into lb_operaciones.tipo_productos values ('TC','TARJETA_CREDITO','Tarjeta de credito', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_productos values ('TD','TARJETA_DEBITO','Tarjeta de debito', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_productos values ('PP','PRESTAMO_PERSONAL','Prestamo personal', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_productos values ('PH','PRESTAMO_HIPOTECARIO','Prestamo hipotecario', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_productos values ('PE','PRESTAMO_EDUCATIVO','Prestamo educativo', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	commit;


	insert into lb_operaciones.tipo_transacciones values ('PPP','PAGO_DE_PRESTAMOS_PERSONALES','Pago de prestamos personales', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_transacciones values ('PPH','PAGOS_DE_PRESTAMOS_HIPOTECARIOS','pago de prestamos hipotecarios', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_transacciones values ('PPE','PAGO_DE_PRESTAMOS_EDUCATIVO','pago de prestamos educativo', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_transacciones values ('PPT','PAGO_DE_PRESTAMOS_DE_TERCEROS','pago de prestamos de terceros', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_transacciones values ('PTC','PAGO_DE_TARJETA_DE_CREDITO','pago de tarjeta de credito', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_transacciones values ('PTCT','PAGO_DE_TARJETA_DE_CREDITO_DE_TERCERO','pago de tarjeta de credito de tercero', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_transacciones values ('TCBP','TRANSFERENCIA_DE_CUENTAS_BANCARIAS_PROPIAS','transferencia de cuentas bancarias propias', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_transacciones values ('TCBT','TRANSFERENCIA_DE_CUENTAS_TERCEROS','transferencia de cuentas terceros', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.tipo_transacciones values ('ATD','ABONO TARJETA DEBITO','Abono a tarjeta de debito', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	commit;


	insert into lb_operaciones.clientes values ('28156794','28156794-AB','vkstark','Veronica','','Stark','','iKOEaJSQwsVfi2sLgsCS71bFfk8ZFTPxtE0mGFwoGjLFoSYhBjadcFdBbNJUhbC/pNQrqoc/OkBQhV+f8qU37Q==',3,'vero@Stark.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.clientes values ('21556785','21556785-AC','bbanner','Bruce','','Banner','','ENj63C08ZHLK3U4PuNgf9+mp6sILLbkI2TpDQGWV80j1Gw1RAoZ8oO4LsdLezr/+H/99liJ7rSq2IAJuFwnGeA==',3,'bruce@banner.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.clientes values ('21556786','21556786-AF','tstark','Tony','','Stark','','f1n9ZdThCJ0RFUUvg91yOksWrLPDKmUmy2Zp2sq1WIt6zgHCgfYI8D/d0sN++BvkBKsbV4jTBGz4PXjk42dUfw==',3,'tony@stark.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.clientes values ('21556787','21556787-AG','tsith','Thanos','','Sith','','R5NebvpUlM4Sfa3fBqOsPtHmu5Vw/hHK9SeasShephg/ckY2RMUuAn6Sflz9LyH6td04VtPJ9LhKDVctnrplhw==',3,'thanos@sith.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.clientes values ('21578708','21578708-AD','obwkenobi','Obi','Wan','kenobi','','ChxF3WXsHjJJSwQkVKyOw6yqXRnh1K3dCLRnbjJXEaLt/kUBeobQAhSwfqV1FAmX+wL4752GjuKSJmF7QKS22Q==',3,'obi.wan@kenobi.com', current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	commit;


	insert into lb_operaciones.productos values ('TDL',1001,'TARJETA DEBITO LIFEMILES','TD','28156794','1',0.00,1200.00,0.00,0.00,current_timestamp, current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.productos values ('TCLI',1002,'TARJETA CREDITO LIFEMILES','TC','21556785','1',2500.00,0.00,34.99,0.00,current_timestamp, current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.productos values ('PPER',1003,'PRESTAMO PERSONAL','PP','21556786','1',6000.00,0.00,8.99,0.00,current_timestamp, current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.productos values ('PHIP',1004,'PRESTAMO HIPOTECARIO','PH','21556787','1',80000.00,0.00,6.99,0.00,current_timestamp, current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.productos values ('PEDU',1005,'PRESTAMO EDUCATIVO','PE','21578708','1',9000.00,0.00,8.99,0.00,current_timestamp, current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.productos values ('TCL',1006,'TARJETA CREDITO LIFEMILES','TC','28156794','1',2800.00,0.00,24.99,0.0,current_timestamp, current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.productos values ('PPGC',1007,'PRESTAMO PERSONAL GASTOS COMUNES','PP','28156794','1',78000.00,0.00,7.99,0.00,current_timestamp, current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');
	insert into lb_operaciones.productos values ('TCPC',1008,'TARJETA CREDITO PUNTOS COLOMBIA','TC','28156794','1',800.00,0.00,28.99,0.00,current_timestamp, current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	commit; 


	insert into lb_operaciones.transaciones(tra_id_transaccion,tra_id_tipo_transaccion,tra_numero_autorizacion, tra_id_producto,tra_id_cliente,tra_id_estado,tra_fecha_transaccion,tra_fecha_proceso,tra_monto,tra_descripcion,tra_cuenta_destino,tra_fecha_creacion, tra_creado_por,tra_fecha_actualizacion, tra_actualizado_por)
	values (1,'ATD','0001','TDL','28156794',9,current_timestamp,current_timestamp,200.00,'Abono a cuenta de debito',1001,current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.transaciones(tra_id_transaccion,tra_id_tipo_transaccion,tra_numero_autorizacion, tra_id_producto,tra_id_cliente,tra_id_estado,tra_fecha_transaccion,tra_fecha_proceso,tra_monto,tra_descripcion,tra_cuenta_destino,tra_fecha_creacion, tra_creado_por,tra_fecha_actualizacion, tra_actualizado_por)
	values (2,'PTC','0002','TCLI','21556785',9,current_timestamp,current_timestamp,300.00,'pago adelantado de cuota TC',1002,current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.transaciones(tra_id_transaccion,tra_id_tipo_transaccion,tra_numero_autorizacion, tra_id_producto,tra_id_cliente,tra_id_estado,tra_fecha_transaccion,tra_fecha_proceso,tra_monto,tra_descripcion,tra_cuenta_destino,tra_fecha_creacion, tra_creado_por,tra_fecha_actualizacion, tra_actualizado_por)
	values (3,'PPE','0003','PPER','21556786',9,current_timestamp,current_timestamp,400.00,'pago adelantado de cuota Prestamo personal',1003,current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.transaciones(tra_id_transaccion,tra_id_tipo_transaccion,tra_numero_autorizacion, tra_id_producto,tra_id_cliente,tra_id_estado,tra_fecha_transaccion,tra_fecha_proceso,tra_monto,tra_descripcion,tra_cuenta_destino,tra_fecha_creacion, tra_creado_por,tra_fecha_actualizacion, tra_actualizado_por)
	values (4,'PPH','0004','PHIP','21556787',9,current_timestamp,current_timestamp,500.00,'pago adelantado de cuota prestamo hipotecario',1004,current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	insert into lb_operaciones.transaciones(tra_id_transaccion,tra_id_tipo_transaccion,tra_numero_autorizacion, tra_id_producto,tra_id_cliente,tra_id_estado,tra_fecha_transaccion,tra_fecha_proceso,tra_monto,tra_descripcion,tra_cuenta_destino,tra_fecha_creacion, tra_creado_por,tra_fecha_actualizacion, tra_actualizado_por)
	values (5,'PPE','0005','PEDU','21578708',9,current_timestamp,current_timestamp,600.00,'pago adelantado de cuota',1005,current_timestamp, 'lb_admin', current_timestamp, 'lb_admin');

	commit;
