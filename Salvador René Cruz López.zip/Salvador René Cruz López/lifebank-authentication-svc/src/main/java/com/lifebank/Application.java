package com.lifebank;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class Application implements CommandLineRunner{
	
	public Application(Environment env) {
		this.env = env;
	}

	private Environment env;
	public static void main(String[] args)  {		
		try {
			System.setProperty("hostname", InetAddress.getLocalHost().getHostName());		
			SpringApplication.run(Application.class, args);
		}catch(UnknownHostException e) {
			e.printStackTrace();
			
		}
				
		
	}

	@Override
	public void run(String... args) throws Exception {	
	}
}
