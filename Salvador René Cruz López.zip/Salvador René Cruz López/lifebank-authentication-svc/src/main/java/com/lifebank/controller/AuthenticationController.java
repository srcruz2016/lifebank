package com.lifebank.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lifebank.exception.IntException;
import com.lifebank.process.LoginProcess;
import com.lifebank.services.authenticateuser.LoginRequest;
import com.lifebank.services.authenticateuser.LoginResponse;


@RestController
@PropertySource("classpath:configuration.properties")
@RequestMapping("${service.url}")
public class AuthenticationController {
	private Environment env;
	private Logger log;
	private LoginProcess loginService;

	@Autowired
	public AuthenticationController(Environment env,LoginProcess loginService) {
		this.env = env;
		this.log = LoggerFactory.getLogger(getClass());
		this.loginService = loginService;
	}
	
	// Endpoint para la Autenticación del usuario de banca en linea de Lifebank.
	@PostMapping("${service.url.endpoint.authentication.login}")
	public LoginResponse authenticateUser(@Valid @RequestBody LoginRequest request,@RequestHeader(value = "ipAddress",required = true) String ipAddress) throws IntException {
		return loginService.getAuthenticateUser(request,ipAddress);
	}
	


}
