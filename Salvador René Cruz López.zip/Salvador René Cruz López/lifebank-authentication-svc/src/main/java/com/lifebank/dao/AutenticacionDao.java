package com.lifebank.dao;

import java.util.List;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.lifebank.pojo.model.Autenticacion;

public interface AutenticacionDao extends CrudRepository<Autenticacion,Integer>{
	
	
	
	@Query("select a from Autenticacion a where a.cliente.idCliente = :codigoCliente order by a.fechaInicioSesion asc")
	public List<Autenticacion> getIntentoFallidos(@Param("codigoCliente") String codigoCliente);
	
	@Query("select count(id) from Autenticacion")
	public Integer getLastRow();


}
