package com.lifebank.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.lifebank.pojo.model.Cliente;

public interface ClienteDao extends CrudRepository<Cliente, Integer>{
	
	/**
	 * Valida la existencia de un cliente en la base de datos, con el parametro:.
	 * @param nombreUsuario
	 * @return String codigo del cliente
	 */
	@Query("select c from Cliente c where c.nombreUsuario = :userName")
	public Cliente getValidUser(@Param("userName") String userName);
	
	/**
	 * Valida las credenciales de un cliente en la base de datos.
	 * @param nombreUsuario
	 * @param contraseña
	 * @return Cliente
	 */
	@Query("select c from Cliente c where c.nombreUsuario = :userName and c.password = :password")
	public Cliente getAuthenticatedUser(@Param("userName") String userName, @Param("password") String password);

}
