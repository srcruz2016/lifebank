package com.lifebank.dao;

import org.springframework.data.repository.CrudRepository;

import com.lifebank.pojo.model.Estado;

public interface EstadoDao extends CrudRepository<Estado,Integer> {

}
