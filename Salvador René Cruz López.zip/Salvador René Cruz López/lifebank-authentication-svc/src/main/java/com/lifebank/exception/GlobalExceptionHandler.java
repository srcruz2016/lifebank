package com.lifebank.exception;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.lifebank.pojo.genericerror.GeneralErrorPojo;

@ControllerAdvice
public class GlobalExceptionHandler {
	private Logger log;
	private Environment env;

	@Autowired
	public GlobalExceptionHandler(Environment env){
		this.log = LoggerFactory.getLogger(getClass());
		this.env = env;		
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value=Exception.class)
	@ResponseBody
	public GeneralErrorPojo handleException(HttpServletRequest req, Exception ex){
		String msg;
		GeneralErrorPojo generalErrorPojo = new GeneralErrorPojo();
		String errorCode = env.getProperty("service.status.error.code");
		String message = env.getProperty("service.status.error.message");

		if (ex.getClass() == MethodArgumentNotValidException.class) {
			MethodArgumentNotValidException bEx;
			bEx = (MethodArgumentNotValidException) ex;

			log.error("Exception not caught: {}", bEx.getBindingResult().getAllErrors().get(0).getDefaultMessage());

			msg = bEx.getBindingResult().getAllErrors().get(0).getDefaultMessage();
				

		}else {
			log.error("Exception not caught: {}", ex.getMessage());
			msg = ex.getMessage();
		}

		
		if (ex.getClass() == IntException.class){
			IntException intEx = (IntException) ex;
			errorCode = intEx.getErrorCode();
			message = intEx.getMessage();
		}else {
			errorCode = env.getProperty("service.status.error.code");
			message = env.getProperty("service.status.error.message");			
		}


		
		try {						
			generalErrorPojo.setCode(errorCode);
			generalErrorPojo.setMessage(message);
		} catch (Exception e) {
			generalErrorPojo = getGenericError(errorCode,msg);
			log.error("{}", e);            
		}
				
		return generalErrorPojo;
	}
	
	/**
	 * 
	 * Devuelve un error generico.
	 */
	private GeneralErrorPojo getGenericError(String code, String message) {
		GeneralErrorPojo generalErrorPojo = new GeneralErrorPojo();
		
		generalErrorPojo.setCode(code);
		generalErrorPojo.setMessage(message);
		return generalErrorPojo;		
	}

}