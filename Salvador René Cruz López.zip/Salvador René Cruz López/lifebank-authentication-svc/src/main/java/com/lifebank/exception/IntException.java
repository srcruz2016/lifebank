package com.lifebank.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IntException extends Exception{
	
	private static final long serialVersionUID = 1L;
	private final String message;
	private final String errorCode;	
	
	public IntException(String message, String errorCode) {
		super();
		this.message = message;
		this.errorCode = errorCode;
	}
		
}
