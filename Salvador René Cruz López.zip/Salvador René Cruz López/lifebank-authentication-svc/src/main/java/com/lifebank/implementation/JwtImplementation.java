package com.lifebank.implementation;

import io.jsonwebtoken.*;

import java.util.Date;
import java.util.Map;

import com.lifebank.repository.JwtRepo;

public class JwtImplementation implements JwtRepo {
    private String secret;
    private Map<String, Object> claims;
    private String subject;
    private String issuer;
    private Long expirationTime;

    public JwtImplementation() {
    }

    //For JwtImplementation Generation
    /**
     * @param claims elements to be saved in the JwtImplementation payload
     * @param secret secret for JwtImplementation
     * @param subject short description about information contained in JwtImplementation
     * @param issuer entity whom creates the JwtImplementation (LifeMiles in this case)
     * @param expirationTime expiration time for JwtImplementation
     */
    public JwtImplementation(Map<String, Object> claims, String secret, String subject, String issuer, Long expirationTime) {
        this.claims = claims;
        this.secret = secret;
        this.subject = subject;
        this.issuer = issuer;
        this.expirationTime = expirationTime;
    }

    //For JwtImplementation Extraction

    /**
     * @param secret secret to decrypt JwtImplementation
     */
    public JwtImplementation(String secret) {
        this.secret = secret;
    }

    //CIPHER
    public String generate(){
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);

        JwtBuilder builder = Jwts.builder();

        //Setting the specific claims (private claims)
        builder.setClaims(this.claims);

        //Setting the standard claims for the payload
        builder.setSubject(this.subject);
        builder.setIssuer(this.issuer);
        builder.setIssuedAt(now);
        builder.setNotBefore(now);
        builder.setExpiration(new Date(nowMillis + this.expirationTime));

        //Cyphering the JwtImplementation
        builder.signWith(SignatureAlgorithm.HS512, this.secret);

        //Generating the JwtImplementation
        String token = builder.compact();
        return token;
    }

    //DECIPHER
    public Claims extract(String jwt) throws ExpiredJwtException, MalformedJwtException, SignatureException{
        //Decrypting the token (Getting the value of the body inside of the token).
        try {
            Claims claims = Jwts.parser()
                    .setSigningKey(this.secret)
                    .parseClaimsJws(jwt)
                    .getBody();
            return claims;

        }
        catch (ExpiredJwtException | MalformedJwtException | SignatureException e){
          throw e;
        }
    }
}
