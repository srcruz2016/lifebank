package com.lifebank.pojo.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="autenticaciones", schema="lb_op_autenticacion")
public class Autenticacion {
		
	@Id
	@Column(name="aut_id_autenticacion")
    int id;
	
	@ManyToOne
	@JoinColumn(name="aut_id_cliente")
    private Cliente cliente;
		
    @ManyToOne
    @JoinColumn(name="aut_estado")
	private Estado estado;
    
    @Column(name="aut_ip_address")
    private String ipAddres;
    
    @Column(name="aut_observaciones")
    private String aut_observaciones;
	
    @Column(name="aut_fecha_inicio_sesion") 
    private Date fechaInicioSesion;
    
}
