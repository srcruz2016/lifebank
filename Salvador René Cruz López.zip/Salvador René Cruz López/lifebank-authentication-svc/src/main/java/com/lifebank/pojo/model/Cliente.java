package com.lifebank.pojo.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="clientes", schema="lb_op_autenticacion")
public class Cliente {
	
	@Id
	@Column(name="cli_id_cliente")
	private String idCliente;
	
	@Column(name="cli_doc_identidad")
	private String documentoIdentidad;
	
	@Column(name="cli_nombre_usuario")
	private String nombreUsuario;
	
	@Column(name="cli_nombre1")
	private String primerNombre;
	
	@Column(name="cli_nombre2")
	private String segundoNombre;
	
	@Column(name="cli_apellido1")
	private String primerApellido;
	
	@Column(name="cli_apellido2")
	private String segundoApellido;
	
	@Column(name="cli_password")
	private String password;
		
    @ManyToOne
    @JoinColumn(name="cli_estado")
     private Estado estado;
	
	@Column(name="cli_correo_electronico")
	private String correoElectronico;
	
	@Column(name="cli_fecha_creacion")
	private Date fechaCreacion;
	
	@Column(name="cli_creado_por")
	private String creadoPor;
	
	@Column(name="cli_fecha_actualizacion")
	private Date fechaModificacion;
	
	@Column(name="cli_actualizado_por")
	private String modificadoPor;
	
	@OneToMany(cascade= CascadeType.ALL)
	@JoinColumn(name="cli_id_cliente")
	private List<Autenticacion> autententicaciones;
	
	

}
