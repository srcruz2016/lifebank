package com.lifebank.pojo.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@Entity
@Table(name="estados", schema="lb_op_autenticacion")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Estado {
	
	@Id
	@Column(name="std_id_estado")
	private int id;
	
	@Column(name="std_estado")
	private String estado;
	
	@Column(name="std_fecha_creacion")
	private Date createdDate;
	
	@Column(name="std_creado_por")
	private String createdBy;
	
	@Column(name="std_fecha_actualizacion")
	private Date modifiedDate;	
	
	@Column(name="std_actualizado_por")
	private String modifiedBy;
	
	@OneToMany(cascade= CascadeType.ALL)
	@JoinColumn(name="std_id_estado")
	private List<Cliente> cliente;
	
	@OneToMany(cascade= CascadeType.ALL)
	@JoinColumn(name="std_id_estado")
	private List<Autenticacion> autententicaciones;
	
}
