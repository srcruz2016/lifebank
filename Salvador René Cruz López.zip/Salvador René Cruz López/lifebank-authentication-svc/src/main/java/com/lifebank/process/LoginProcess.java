package com.lifebank.process;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.Security;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.lifebank.dao.AutenticacionDao;
import com.lifebank.dao.ClienteDao;
import com.lifebank.dao.EstadoDao;
import com.lifebank.exception.IntException;
import com.lifebank.implementation.JwtImplementation;
import com.lifebank.pojo.model.Autenticacion;
import com.lifebank.pojo.model.Cliente;
import com.lifebank.pojo.model.Estado;
import com.lifebank.repository.AuthenticationRepo;
import com.lifebank.repository.EncriptRepo;
import com.lifebank.repository.LoginRepo;
import com.lifebank.services.authenticateuser.LoginRequest;
import com.lifebank.services.authenticateuser.LoginResponse;

@Service
public class LoginProcess implements LoginRepo, EncriptRepo, AuthenticationRepo {

	private Environment env;
	private Logger log;
	private ClienteDao clienteDao;
	private AutenticacionDao autenticacionDao;
	private EstadoDao estadoDao;
	private int maxIntentosValidos;
	private final int stateCodeSuccesful ;
	private final int stateCodeFailed;
	private final int stateCodeBlocked;
	private final int nIntentosFallidos;
	
	
	@PersistenceContext
    private EntityManager entityManager;

	@Autowired
	public LoginProcess(Environment env, ClienteDao clienteDao, AutenticacionDao autenticacionDao,EstadoDao estadoDao) {
		this.env = env;
		this.clienteDao = clienteDao;
		this.log = LoggerFactory.getLogger(getClass());
		this.autenticacionDao = autenticacionDao;
		this.estadoDao = estadoDao;
		this.maxIntentosValidos = Integer.valueOf(env.getProperty("service.user.config.validation.numero-intentos-fallidos"));
		this.stateCodeSuccesful = Integer.valueOf(env.getProperty("service.user.status-code.exito"));
		this.stateCodeFailed = Integer.valueOf(env.getProperty("service.user.status-code.fallido"));
		this.nIntentosFallidos = Integer.parseInt(env.getProperty("service.user.config.numero-intentos-fallidos"));
		this.stateCodeBlocked = Integer.parseInt(env.getProperty("service.user.status-code.bloqueado"));
	}

	@Override
	public LoginResponse getAuthenticateUser(LoginRequest loginRequest, String ipAddress) throws IntException {
		LoginResponse loginResponse = new LoginResponse();

		
		Cliente cliente = new Cliente();
					
		cliente = clienteDao.getValidUser(loginRequest.getUserName());
		
		Integer intentosFallidos = getFailedLogin(cliente);
		
		// Valido la cantidad de Intentos Fallidos
		if (intentosFallidos == maxIntentosValidos) {
			log.info("Se Bloqueo el usuario: " + cliente.getNombreUsuario()+" con id: "+ cliente.getIdCliente() + " por exceder el limite de intentos fallidos." );
			
			// Cambio el estado del cliente a Bloqueado. 			
			Optional<Estado> estado  = estadoDao.findById(stateCodeBlocked);							
			cliente.setEstado(estado.get());			
			clienteDao.save(cliente);
			//Responde con estado 400 y finaliza el proceso.
			throw new IntException(env.getProperty("service.configuration.http.user-blocked-msg"), env.getProperty("service.configuration.http.user-blocked-code"));
		} else {
			// Sigue el flujo
				
			// Realizo el encode a los datos del usuario
			String password = Base64.encodeBase64String(loginRequest.getUserName().getBytes())
					+ Base64.encodeBase64String(loginRequest.getPassword().getBytes());
			password = getCipherText(password);

			//valido si las credenciales ingresadas coinciden genero el token.
			// Valido que el usuario tenga estado activo 
			if ((env.getProperty("service.user.status.activo").equalsIgnoreCase(cliente.getEstado().getEstado()))
					& (password.equalsIgnoreCase(cliente.getPassword()))) {
				
				loginResponse.setTkn(generateJWT(cliente, ipAddress));
				
				// Guardo el intento como exitoso.
				saveAuthenticationAttempt(ipAddress, cliente,stateCodeSuccesful,env.getProperty("service.config.observation.success"));
			} else {
				// debo de guardar en la tabla de intentos fallidos y lanzar el mensaje HTTP 401.
				log.info("Intento fallido numero: " + intentosFallidos +" UserName: " +cliente.getNombreUsuario());
				saveAuthenticationAttempt(ipAddress, cliente,stateCodeFailed,env.getProperty("service.config.observation.failed"));
				throw new IntException(env.getProperty("service.configuration.http.bad-credential-msg"), env.getProperty("service.configuration.http.bad-credential-code"));				
			}
			
		}
		
	
		return loginResponse;
	}

	@Override
	public void saveAuthenticationAttempt(String ipAddress, Cliente cliente,Integer estateCode,String observacion) {
		Autenticacion autenticacion = new Autenticacion();
		
		try {
			
			Integer lastRow = autenticacionDao.getLastRow(); 
			Optional<Estado> estado  = estadoDao.findById(estateCode);		
			autenticacion.setId(lastRow + 1);
			autenticacion.setIpAddres(ipAddress);
			autenticacion.setFechaInicioSesion(new Date());
			autenticacion.setEstado(estado.get());
			autenticacion.setAut_observaciones(observacion);
			autenticacion.setCliente(cliente);										
			autenticacionDao.save(autenticacion);
		} catch (Exception e) {
			log.error("Microservicio: lifebank-authentication-svc, error: {}, en la linea: {}, metodo: {}", e,
					e.getStackTrace()[0].getLineNumber(), e.getStackTrace()[0].getMethodName());
			e.printStackTrace();
		}
	
	}

	@Override
	public Integer getFailedLogin(Cliente cliente) {	
		List<Autenticacion> autenticaciones = new ArrayList<Autenticacion>();	
		
		//contador intentos fallidos.
		Integer nIntentos = 0;
		try {
			// retorno una lista de intentos fallidos ordenados ASC.
			autenticaciones = autenticacionDao.getIntentoFallidos(cliente.getIdCliente());
			if ((autenticaciones != null)) {

				for (Autenticacion autenticacion : autenticaciones) {
					if (autenticacion.getEstado().getId() == stateCodeFailed) {
						if (nIntentos <= nIntentosFallidos) {
							nIntentos = nIntentos + 1;
						} else {
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("Microservicio: lifebank-authentication-svc, error: {}, en la linea: {}, metodo: {}", e,
					e.getStackTrace()[0].getLineNumber(), e.getStackTrace()[0].getMethodName());
			log.info("Usuario no encontrado");
		}

	return nIntentos;
	}

	@Override
	public String generateJWT(Cliente cliente, String ipAddress)throws IntException  {

		String jwt = null;
		Map<String, Object> mapJWT = new HashMap<String, Object>();
		mapJWT.put("ipAddress", "localhost");
		mapJWT.put("clientID", cliente.getIdCliente());
		mapJWT.put("ipAddress", ipAddress);

		JwtImplementation jwtGenerator = new JwtImplementation(mapJWT, env.getProperty("service.jwt.secret"),
				env.getProperty("service.jwt.subject"), env.getProperty("service.jwt.issuer"),
				Long.parseLong(env.getProperty("service.jwt.expiration-time")));

		jwt = jwtGenerator.generate();
		log.info((jwt != null) ? "JWT generado exitosamente para el cliente: -> " + cliente.getIdCliente()
				: "Revisar datos del jwt");
		return jwt;
	}

	// implementacion particular para el método getCipherText.
	@Override
	public String getCipherText(String text) {
		String password = null;
		Security.addProvider(new BouncyCastleProvider());

		try {
			MessageDigest mda = MessageDigest.getInstance("SHA-512", "BC");
			byte[] digesta = mda.digest(text.getBytes());
			password = new String(Base64.encodeBase64(digesta), "UTF-8");
		} catch (NoSuchAlgorithmException | NoSuchProviderException | UnsupportedEncodingException e) {
			log.error("Microservicio: lifebank-authentication-svc, error: {}, en la linea: {}, metodo: {}", e,
					e.getStackTrace()[0].getLineNumber(), e.getStackTrace()[0].getMethodName());
			e.printStackTrace();

		}

		return password;
	}
		
}
