package com.lifebank.repository;

import com.lifebank.pojo.model.Cliente;

public interface AuthenticationRepo {
	/**
	 * Método para almacenar los intentos de autenticación de usuario, posibles valores Exitoso o Fallido.
	 * @param ipAddress
	 * @param cliente
	 * @param estateCode
	 * @return void
	 */
	public void saveAuthenticationAttempt(String ipAddress, Cliente cliente,Integer estateCode,String observacion);
	/**
	 * Método para obtener la cantidad de intentos fallidos registrados en la base de datos por un usuario.
	 * @param cliente
	 * @return Integer
	 */
	public Integer getFailedLogin(Cliente cliente);

}
