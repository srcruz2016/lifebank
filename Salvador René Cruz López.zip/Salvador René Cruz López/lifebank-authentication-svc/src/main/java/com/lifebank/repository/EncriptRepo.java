package com.lifebank.repository;


public interface EncriptRepo {
	/**
	 * Método para cifrar la informacion del usuario.
	 * @param text
	 * @return textCifrado
	 */
	public String getCipherText(String text);
	

}
