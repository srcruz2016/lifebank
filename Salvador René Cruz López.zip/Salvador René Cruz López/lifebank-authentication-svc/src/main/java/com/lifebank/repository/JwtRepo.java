package com.lifebank.repository;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;

public interface JwtRepo {
	public String generate();
	public Claims extract(String jwt) throws ExpiredJwtException, MalformedJwtException, SignatureException;
}
