package com.lifebank.repository;

import com.lifebank.exception.IntException;
import com.lifebank.pojo.model.Cliente;
import com.lifebank.services.authenticateuser.LoginRequest;
import com.lifebank.services.authenticateuser.LoginResponse;


public interface LoginRepo {	
	/**
	 * Método para el Procesamiento de solicitud de Login de un usuario de lifebank.
	 * @param loginRequest
	 * @param ipAddress
	 * @return LoginResponse
	 */
	public LoginResponse getAuthenticateUser(LoginRequest loginRequest,String ipAddress) throws IntException ;
	
	/**
	 * Método para la generación de un jwt con los datos del cliente según RFC-7519.
	 * @param cliente
	 * @param ipAddress
	 * @return String JWT
	 */
	public String generateJWT(Cliente cliente, String ipAddress)throws IntException ;

}
