package com.lifebank.services.authenticateuser;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonPropertyOrder({
    "tkn"
})
public class LoginResponse {
	private String tkn;
	
	
}
